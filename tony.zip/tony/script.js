let sliders = document.querySelectorAll("input[type='range']");

sliders.forEach(slider => {
slider.addEventListener("input", updateEnergy);
});

function updateEnergy(){
let total = 0;

sliders.forEach(slider=>{
total += parseInt(slider.value);
});

if(total > 100){
alert("Energy exceeded! Reduce allocation.");
}
}